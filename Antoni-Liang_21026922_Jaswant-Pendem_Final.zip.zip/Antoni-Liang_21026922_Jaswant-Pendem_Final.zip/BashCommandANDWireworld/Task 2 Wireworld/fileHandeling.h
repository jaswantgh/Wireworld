#ifndef FILEHANDELING_H
#define FILEHANDELING_H

void getDimensionsFromFile(char *filename, int *rows, int *cols);
int *readFile(char *filename);

#endif
