#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fileHandeling.h"
#include "newSleep.h"
#include "map.h"

int main(int argc, char const *argv[])
{
    int errorCode = 0;  /* 0 = success and 1 =error */
    char *filename = NULL;
    int* map = NULL;
    int steps = 0, rows = -1, cols = -1;
    float sleepLength = 0;
    int i = 0;
    char* endptr;

    if (argc >= 4) {
        filename = (char*)malloc((strlen(argv[1])+1) * sizeof(char));
        if (filename != NULL) {
            strcpy(filename, argv[1]);
            steps = strtol(argv[2], &endptr, 10);
            if (*endptr == '\0') {
                sleepLength = (float)strtod(argv[3], &endptr);
                if (*endptr == '\0') {
                    getDimensionsFromFile(filename, &rows, &cols);
                    if (rows != -1 && cols != -1) {
                        map = readFile(filename);
                        if (map != NULL) {
                            for (i = 0; i < steps; i++) {
                                simulate(map, rows, cols);
                                newSleep(sleepLength);
                            }
                        } else {
                            printf("Failed to read the file or allocate memory for the map.\n");
                            errorCode = 1;
                        }
                    } else {
                        printf("Failed to get dimensions from the file.\n");
                        errorCode = 1;
                    }
                } else {
                    printf("Sleep length must be number (can be decimal or whole).\n");
                    errorCode = 1;
                }
            } else {
                printf("Steps amount must be a whole number.\n");
                errorCode = 1;
            }
            free(filename);
        } else {
            printf("Failed to allocate memory for filename.\n");
            errorCode = 1;
        }
    } else {
        printf("Usage: ./wireworld <file_name> <steps_amount> <sleep_length>\n");
        errorCode = 1;
    }
    
    if (map != NULL) {
        free(map);
    }

    return errorCode;
}
