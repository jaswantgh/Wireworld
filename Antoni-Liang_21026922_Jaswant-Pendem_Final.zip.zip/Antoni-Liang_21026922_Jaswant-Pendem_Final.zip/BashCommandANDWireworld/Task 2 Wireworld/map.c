#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "color.h"
#include "map.h"

int* allocateMemory(int rows, int cols);
void copyMap(int* source, int* target, int rows, int cols);
void processMap(int* map, int* nextMap, int rows, int cols);
void processCell(int* map, int* nextMap, int i, int j, int rows, int cols);
int countElectronHeads(int* map, int i, int j, int rows, int cols);
int checkNeighbor(int* map, int i, int j, int dx, int dy, int rows, int cols);
void printCell(int* map, int index);

/* Print map with color cells */
void printMap(int* map, int rows, int cols) {
    int i;
    system("clear");
    for (i = 0; i < rows * cols; i++) {
        printCell(map, i);
        if ((i + 1) % cols == 0) {
            printf("\n");
        }
    }
    printf("\n");
}

/* Print cell with appropriate colors */
void printCell(int* map, int index) {
    switch (map[index]) {
        case EMPTY:
            setBackground("black");
            printf("  ");
            setBackground("reset");
            break;
        case HEAD:
            setBackground("blue");
            printf("  ");
            setBackground("reset");
            break;
        case TAIL:
            setBackground("red");
            printf("  ");
            setBackground("reset");
            break;
        case CONDUCTOR:
            setBackground("yellow");
            printf("  ");
            setBackground("reset");
            break;
        default:
            break;
    }
}

/* Simulate game by updating map */
void simulate(int* map, int rows, int cols) {
    int* nextMap = allocateMemory(rows, cols);
    copyMap(map, nextMap, rows, cols);
    processMap(map, nextMap, rows, cols);
    printMap(map, rows, cols);
    free(nextMap);
}

/* Allocate memory for Map */
int* allocateMemory(int rows, int cols) {
    return (int*)malloc(rows * cols * sizeof(int));
}

/* Copy source map to target map */
void copyMap(int* source, int* target, int rows, int cols) {
    int i;
    for (i = 0; i < rows * cols; i++) {
        target[i] = source[i];
    }
}

/* Processes map by updating cell */
void processMap(int* map, int* nextMap, int rows, int cols) {
    int i, j;
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            processCell(map, nextMap, i, j, rows, cols);
        }
    }
    copyMap(nextMap, map, rows, cols);
}

/* Process single cell by updating map */
void processCell(int* map, int* nextMap, int i, int j, int rows, int cols) {
    int currentIndex = i * cols + j;
    int currentCell = map[currentIndex];
    int electronHeads = 0;

    if (currentCell == HEAD) {
        nextMap[currentIndex] = TAIL;
    } else if (currentCell == TAIL) {
        nextMap[currentIndex] = CONDUCTOR;
    } else if (currentCell == CONDUCTOR) {
        electronHeads = countElectronHeads(map, i, j, rows, cols);
        if (electronHeads == 1 || electronHeads == 2) {
            nextMap[currentIndex] = HEAD;
        }
    }
}

/* Moore neighborhood */

/* Count the no. of neighboring electrons */
int countElectronHeads(int* map, int i, int j, int rows, int cols) {
    int electronHeads = 0, x, y;

    for (x = -1; x <= 1; x++) {
        for (y = -1; y <= 1; y++) {
            electronHeads += checkNeighbor(map, i, j, x, y, rows, cols);
        }
    }

    return electronHeads;
}

/* Check if neighboring cell is an electron head */
int checkNeighbor(int* map, int i, int j, int dx, int dy, int rows, int cols) {
    int neighborX = i + dx;
    int neighborY = j + dy;
    int result = 0;

    if (dx != 0 || dy != 0) {
        if (neighborX >= 0 && neighborX < rows && neighborY >= 0 && neighborY < cols) {
            int neighborIndex = neighborX * cols + neighborY;
            if (map[neighborIndex] == HEAD) {
                result = 1;
            }
        }
    }

    return result;
}
