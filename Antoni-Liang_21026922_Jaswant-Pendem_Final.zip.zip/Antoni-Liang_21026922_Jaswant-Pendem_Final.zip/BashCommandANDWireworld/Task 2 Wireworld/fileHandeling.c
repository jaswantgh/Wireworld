#include <stdio.h>
#include <stdlib.h>
#include "fileHandeling.h"

/* Gets dimensions (rows and columns) */
void getDimensionsFromFile(char *filename, int *rows, int *cols) {
    FILE *file;
    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Failed to open the file.\n");
        return;
    }
    fscanf(file, "%d %d", rows, cols);
    fclose(file);
}

/* Reads file and returns map as array */
int *readFile(char *filename) {
    int cols = 0, rows = 0;
    int temp;
    int i = 0;
    int *map = NULL;
    FILE *file;
    char line[100];

    getDimensionsFromFile(filename, &rows, &cols);
    map = (int *)malloc(rows * cols * sizeof(int));

    if (map != NULL) {
        file = fopen(filename, "r");
        if (file != NULL) {
            fgets(line, sizeof(line), file);

            while (fscanf(file, "%d", &temp) == 1) {
                map[i] = temp;
                i++;
            }
            fclose(file);

            if (i != rows * cols) {
                printf("Error reading file contents.\n"); /* Exception handling */
                free(map);
                map = NULL;
            }
        } else {
            printf("Failed to open the file.\n");
            free(map);
            map = NULL;
        }
    } else {
        printf("Failed to allocate memory.\n");
    }

    return map;
}
