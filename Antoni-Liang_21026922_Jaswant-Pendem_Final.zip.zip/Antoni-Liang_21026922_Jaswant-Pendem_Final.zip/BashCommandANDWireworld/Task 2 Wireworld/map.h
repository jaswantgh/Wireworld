#ifndef MAP_H
#define MAP_H

#define EMPTY 0
#define HEAD 1
#define TAIL 2
#define CONDUCTOR 3

void printMap(int* map, int rows, int cols);
void simulate(int* map, int rows, int cols);

#endif

